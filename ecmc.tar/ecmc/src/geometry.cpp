#include "geometry.h"
#include <cmath>

// 所有几何类的实现已移至头文件以支持内联优化
