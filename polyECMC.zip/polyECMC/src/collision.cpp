#include "collision.h"
#include <cmath>

// Numerical tolerance (accounting for floating-point accumulation errors)
static const double EPSILON = 1e-16;  // Several orders of magnitude larger than machine precision

CollisionEvent findCollisionX(
    const CellGrid& grid,
    int activeCellID,
    int activeSlotK,
    const IGeometry& geom,
    double maxDistance)
{
    // X-direction search: only search forward 6 neighbor cells
    // 3x3 neighborhood encoding:
    //   6  7  8
    //   3  4  5
    //   0  1  2
    // Forward (+X direction): 2(bottom-right), 5(right-middle), 8(top-right), 1(bottom), 4(center), 7(top)
    static const std::vector<int> xDirections = {2, 5, 8, 1, 4, 7};
    
    // Get active particle information
    double activeRadius = grid.getRadius(activeCellID, activeSlotK);
    int activeParticleID = grid.getParticleID(activeCellID, activeSlotK);
    
    // Initialize nearest collision (distance = INF indicates no collision)
    CollisionEvent minEvent;
    // minEvent.distance defaults to INF (set by constructor)
    
    // Iterate through forward neighbors
static int dbg_count = 0;

grid.forEachNeighbor(activeCellID, activeSlotK, xDirections,
[&](int targetCellID, int targetSlotK, double dx, double dy, double targetRadius) {

    int targetParticleID = grid.getParticleID(targetCellID, targetSlotK);
    if (activeParticleID == targetParticleID) return;

    if (dx < 1e-12) return;
    double eventDist = geom.XeventDistance(dx, dy, activeRadius, targetRadius);
    if (std::isnan(eventDist)) {
        // If geometric calculation fails due to numerical instability,
        // we must treat this event as impossible.
        eventDist = std::numeric_limits<double>::infinity();
    }
    if (eventDist < 0) eventDist = 0.0;

    if (eventDist < minEvent.distance) {
        minEvent.distance = eventDist;
        minEvent.targetCellID = targetCellID;
        minEvent.targetSlotK = targetSlotK;
        minEvent.dxInitial = dx;
        minEvent.dyInitial = dy;
        minEvent.deltaIJ = dx - eventDist;
    }
});

    
    return minEvent;
}

CollisionEvent findCollisionY(
    const CellGrid& grid,
    int activeCellID,
    int activeSlotK,
    const IGeometry& geom,
    double maxDistance)
{
    // Y-direction search: only search forward 6 neighbor cells
    // Forward (+Y direction): 6(top-left), 7(top), 8(top-right), 3(left), 4(center), 5(right)
    static const std::vector<int> yDirections = {6, 7, 8, 3, 4, 5};
    
    // Get active particle information
    double activeRadius = grid.getRadius(activeCellID, activeSlotK);
    int activeParticleID = grid.getParticleID(activeCellID, activeSlotK);
    
    // Initialize nearest collision (distance = INF indicates no collision)
    CollisionEvent minEvent;
    
    // Iterate through forward neighbors
    grid.forEachNeighbor(activeCellID, activeSlotK, yDirections,
        [&](int targetCellID, int targetSlotK, double dx, double dy, double targetRadius) {
            // 1. Avoid self-collision
            int targetParticleID = grid.getParticleID(targetCellID, targetSlotK);
            if (activeParticleID == targetParticleID) {
                return;
            }
            if (dy<1e-12){
                return;
            }
            // 3. Calculate event distance
            double eventDist = geom.YeventDistance(dx, dy, activeRadius, targetRadius);
                if (std::isnan(eventDist)) {
                    // If geometric calculation fails due to numerical instability,
                    // we must treat this event as impossible.
                    eventDist = std::numeric_limits<double>::infinity();
                }
            if(eventDist<0){
                eventDist=0.0;
            }

            // 7. Update minimum event
            if (eventDist < minEvent.distance) {
                minEvent.distance = eventDist;
                minEvent.targetCellID = targetCellID;
                minEvent.targetSlotK = targetSlotK;
                minEvent.dxInitial = dx;
                minEvent.dyInitial = dy;
                // deltaIJ = dy - eventDist (Y-direction contact distance at collision time)
                minEvent.deltaIJ = dy - eventDist;
            }
        });
    
    return minEvent;
}
