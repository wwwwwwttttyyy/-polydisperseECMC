# ECMC - Event-Chain Monte Carlo for Hard Disks

Efficient 2D hard disk system Event-Chain Monte Carlo (ECMC) simulation program, supporting polydisperse systems and pressure measurement.

## Features

- ✅ **Efficient Cell Grid Algorithm** - O(1) collision detection
- ✅ **Periodic Boundary Conditions** - Proper handling of particle cross-boundary movement
- ✅ **Pressure Measurement** - Accurate pressure calculation based on collision accumulation
- ✅ **Polydisperse Systems** - Support for particle radius distributions
- ✅ **Snapshot Output** - Periodic saving of system configurations
- ✅ **Statistical Analysis** - Automatic separation of equilibration and production phases
- ✅ **Binary I/O** - Binary format saving ~9% storage space

## Building

### Requirements

- CMake 3.15+
- C++11 compiler (GCC, Clang, MSVC)
- Ninja (optional, recommended)

### Build Steps

```bash
# Windows (PowerShell)
mkdir build
cd build
cmake .. -G Ninja -DCMAKE_BUILD_TYPE=Release
ninja

# Linux/Mac
mkdir build && cd build
cmake .. -DCMAKE_BUILD_TYPE=Release
make -j
```

## Usage

### Preparing Initial Configuration

The program requires an initial configuration file as input. The project provides an example file `config_initial.dat` (256 particles, φ=0.70).

Also included are several bidisperse circle-packing configuration files for testing polydisperse performance: `config1_vf_0.850.dat`, `config1_vf_0.740.dat`.

**Text Format**:
```text
33.8958 33.8958              # Line 1: box dimensions Lx Ly
-15.8887 -15.8887 1.01186    # Line 2+: x y radius (one line per particle)
-15.8887 -13.7702 0.987337
-15.8887 -11.6517 1.01119
...
```

**Note**: Coordinate system is centered at box origin, range [-Lx/2, Lx/2) × [-Ly/2, Ly/2)

### 1. Using Parameter File (Recommended)

Create a parameter file `params.txt`:

```text
input_file = config_initial.dat
n_chains = 1000000
sample_interval_pressure = 50000
sample_interval_snapshot = 100000
n_equilibration_pressure = 100000
rng_seed = 42
```

Run simulation:

```bash
./ecmc_main -p params.txt
```

### 2. Pure Command Line Mode

```bash
./ecmc_main -i initial.dat -n 1000000 -s 50000 -e 100000
```

### 3. Mixed Mode (Command Line Overrides Parameter File)

```bash
./ecmc_main -p params.txt -n 2000000 -s 100000
```

## Parameter Description

| Parameter | Short Option | Default | Description |
|-----------|--------------|---------|-------------|
| `input_file` | `-i` | *Required* | Initial configuration file |
| `output_file` | `-o` | `config_final.dat` | Output configuration file |
| `n_chains` | `-n` | 100000 | Total number of event chains |
| `chain_length` | `-l` | 1.0 | Chain length (multiple of box size) |
| `sample_interval_pressure` | `-s` | 10000 | Pressure sampling interval |
| `sample_interval_snapshot` | `-S` | 0 | Snapshot output interval (0=disabled) |
| `n_equilibration_pressure` | `-e` | 0 | Number of chains for pressure equilibration |
| `rng_seed` | `-r` | *Random* | Random number seed |
| `binary_output` | `-b` | false | Use binary output |

## Output Files

### 1. Final Configuration (`config_final.dat`)

Contains particle positions and radii at the end of simulation.

**Text Format**:
```text
256         # Number of particles
33.8958 33.8958    # Box dimensions
-3.142 5.678 1.000  # x y radius
...
```

**Binary Format**: Use `-b` option, saves ~9% space.

### 2. Pressure Data (`pressure_data.txt`)

Contains complete pressure statistics:

```text
# Production Statistics (after equilibration):
#   betaP* = 9.28974 +/- 0.0483076
#   Px     = 9.31525 +/- 0.0632583
#   Py     = 9.26423 +/- 0.0548891
#
# Sample  Chains  betaP*   Px       Py       Phase
0  50000  9.5959  9.6123  9.5795  equilibration
1  100000 9.3621  9.4012  9.3230  production
...
```

### 3. Snapshot Files (`snapshot_*.dat`)

Periodically saved configuration files, filename format: `snapshot_00000100000.dat`

Enable with `-S` option, e.g., `-S 100000` saves every 100,000 chains.

## Pressure Calculation Formula

This program uses collision-based pressure calculation method:

$$
\beta P^* = \left[\rho + \rho \cdot \frac{\sum_i \delta_i}{L}\right] \times (2\bar{r})^2
$$

Where:
- $\rho = N/V$ - Number density
- $\delta_i$ - Free path reduction for the $i$-th collision
- $L = n_{\text{chains}} \times l_{\text{chain}}$ - Total chain length
- $\bar{r}$ - Average particle radius



## Performance Recommendations

1. The input configuration should be as centrosymmetric as possible.
2. Avoid placing atoms exactly on the box boundaries.

## References

1. Bernard et al., "Two-Step Melting in Two Dimensions: First-Order Liquid-Hexatic Transition," Phys. Rev. Lett., vol. 107, no. 15, p. 155704, 2011. DOI: 10.1103/PhysRevLett.107.155704

## License

MIT License

## Authors

Tianyu Wei
