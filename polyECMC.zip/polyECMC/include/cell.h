#pragma once
#include "para.h"
#include "system.h"
#include <vector>
#include <array>
#include <random>
#include "geometry.h"
class CellGrid {
public:
    // ========== Construction and Initialization ==========
    /**
     * @brief Construct CellGrid (automatically compute optimal grid)
     * @param sys Particle system (for box, radiusMax, radiusMin, N)
     * @param maxOccupancy Maximum occupancy per cell (default -1: auto-compute)
     * 
     * Grid size auto-optimization:
     *  - cellSize >= 2.5 * radiusMax (safety margin)
     *  - totalCells ~ sqrt(N) to 2*N (performance balance)
     * 
     * maxOccupancy auto-compute (when <= 0):
     *  - Formula: (cellSizeX/(2*rmin) + 1) * (cellSizeY/(2*rmin) + 1) / (sqrt(3)/2) + 1
     *  - Physical meaning: hexagonal close packing value + 1
     */
    explicit CellGrid(const System& sys, int maxOccupancy = -1);
    
    /**
     * @brief Construct CellGrid (manually specify grid)
     * @param sys Particle system
     * @param nx Number of cells in X direction
     * @param ny Number of cells in Y direction
     * @param maxOccupancy Maximum occupancy per cell (-1 auto, otherwise use specified)
     * 
     * For debugging or special cases, ensure cellSize >= 2*radiusMax
     */
    CellGrid(const System& sys, int nx, int ny, int maxOccupancy = -1);
    
    // ========== Core Operations ==========
    /**
     * @brief Rebuild the entire grid from System
     * @param sys Particle system
     * 
     * Usage: call after initialization or large changes in particle positions/radii
     * Complexity: O(N)
     */
    void rebuild(const System& sys);
    
    /**
     * @brief Randomly select an active particle
     * @param rng Random number generator
     * @return {cellID, slotK} Position of active particle in cell
     * 
     * Algorithm: rejection sampling (consistent with HistoricDisks)
     */
    std::pair<int, int> chooseActive(std::mt19937& rng);
    
    /**
     * @brief Update particle position (handle cross-cell movement and sync System global coordinates)
     * @param sys Particle system (for syncing global coordinates)
     * @param cellID Current cell ID
     * @param slotK Current slot
     * @param deltaX Displacement in X
     * @param deltaY Displacement in Y
     * @return {newCellID, newSlotK} Updated position
     * 
     * Automatically handles:
     *  - Computes new global coordinates and applies PBC
     *  - Syncs sys.x or sys.y
     *  - Intra-cell move: update relative coordinates in place
     *  - Inter-cell move: swap-tail remove + append to new cell
     */
    std::pair<int, int> moveParticle(System& sys, int cellID, int slotK, 
                                      double deltaX, double deltaY);
    
    // ========== Data Access (read-only, for collision detection) ==========
    /// Get relative coordinates
    double getRelX(int cellID, int slotK) const;
    double getRelY(int cellID, int slotK) const;
    
    /// Get radius
    double getRadius(int cellID, int slotK) const;
    
    /// Get global particle ID (optional, for debugging)
    int getParticleID(int cellID, int slotK) const;
    
    /// Get cell occupancy
    int getOccupancy(int cellID) const;
    
    /// Get neighbor cell ID (9-grid index 0-8)
    int getNeighbor(int cellID, int direction) const;
    
    // ========== General Neighbor Traversal (core interface) ==========
    /**
     * @brief Traverse neighbor particles in specified directions
     * @param activeCellID Cell of active particle
     * @param activeSlotK Slot of active particle
     * @param directions List of directions to search (9-grid code 0-8)
     * @param callback Callback function, signature:
     *        void(int targetCellID, int targetSlotK, 
     *             double dx, double dy, double targetRadius)
     *        where dx, dy are the target's position relative to the active particle (PBC handled)
     * 
     * 9-grid code:
     *   6  7  8
     *   3  4  5
     *   0  1  2
     * 
     */
    template<typename Func>
    void forEachNeighbor(
        int activeCellID,
        int activeSlotK,
        const std::vector<int>& directions,
        Func callback) const;
    
    /**
     * @brief Get global center coordinates of a cell
     * @param cellID Cell index
     * @return {centerX, centerY} Global coordinates (box center at origin)
     */
    std::pair<double, double> getCellCenter(int cellID) const;
    
    int getNx() const { return nx_; }
    int getNy() const { return ny_; }
    int getTotalCells() const { return totalCells_; }
    double getCellSizeX() const { return cellSizeX_; }
    double getCellSizeY() const { return cellSizeY_; }
    int getMaxOccupancy() const { return maxOccupancy_; }
    
private:
    // ========== Grid Geometry Parameters ==========
    int nx_, ny_;                      ///< Grid dimensions
    int totalCells_;                   ///< nx * ny
    double cellSizeX_, cellSizeY_;     ///< Cell edge length
    int maxOccupancy_;                 ///< Max occupancy per cell
    std::array<double, 2> boxSize_;    ///< Box boundaries (cached)
    
    // ========== Cell Data (SoA in cell) ==========
    /// Cell occupancy [totalCells]
    std::vector<int> occupancy_;
    
    /// Relative coordinates [totalCells][maxOccupancy] (flattened storage)
    std::vector<double> relPosX_;
    std::vector<double> relPosY_;
    
    /// Radius [totalCells][maxOccupancy] (polydisperse key!)
    std::vector<double> cellRadius_;
    
    /// Global particle ID [totalCells][maxOccupancy] (optional, for debugging)
    std::vector<int> particleID_;
    
    // ========== Neighbor Table (precomputed) ==========
    /// 9-grid neighbors [totalCells][9]
    /// Code: 0-8 corresponds to:
    ///   6  7  8
    ///   3  4  5
    ///   0  1  2
    std::vector<std::array<int, 9>> neighbors_;
    
    // ========== Helper Methods ==========
    /// Cell ID mapping: (ix, iy) -> cellID
    int cellIndex(int ix, int iy) const;
    
    /// Cell ID reverse mapping: cellID -> (ix, iy)
    std::pair<int, int> cellCoords(int cellID) const;
    
    /// Build neighbor table (considering PBC)
    void buildNeighborTable();
    
    /// Swap-tail remove (O(1))
    void swapRemove(int cellID, int slotK);
    
    /// Automatically compute optimal grid size
    static std::pair<int, int> computeOptimalGrid(
        const std::array<double, 2>& boxSize, 
        double radiusMax, 
        int numParticles);
    
    /// 2D index flattening: cellID * maxOccupancy + slotK
    int flatIndex(int cellID, int slotK) const {
         return static_cast<size_t>(cellID) * maxOccupancy_ + slotK;
    }
};

// ========== Template Method Implementation ==========

template<typename Func>
void CellGrid::forEachNeighbor(
    int activeCellID,
    int activeSlotK,
    const std::vector<int>& directions,
    Func callback) const
{
    // Get the relative coordinates and radius of the active particle
    int activeSlot = flatIndex(activeCellID, activeSlotK);
    double activeRelX = relPosX_[activeSlot];
    double activeRelY = relPosY_[activeSlot];
    
    // Get the center coordinates of the cell containing the active particle
    std::pair<int, int> activeCoords = cellCoords(activeCellID);
    int activeIx = activeCoords.first;
    int activeIy = activeCoords.second;
    double activeCenterX = (activeIx + 0.5) * cellSizeX_ - boxSize_[0] / 2.0;
    double activeCenterY = (activeIy + 0.5) * cellSizeY_ - boxSize_[1] / 2.0;
    
    // Global coordinates of the active particle (for minimum image)
    std::pair<int,int> aCoords = cellCoords(activeCellID);
    double aCenterX = (aCoords.first + 0.5) * cellSizeX_ - boxSize_[0] / 2.0;
    double aCenterY = (aCoords.second + 0.5) * cellSizeY_ - boxSize_[1] / 2.0;
    double aGlobalX = aCenterX + activeRelX;
    double aGlobalY = aCenterY + activeRelY;

    // Traverse neighbors in specified directions (using global coordinates + minimum image)
    for (int dir : directions) {
        int neighborCellID = neighbors_[activeCellID][dir];
        int ocp = occupancy_[neighborCellID];
        std::pair<int,int> nCoords = cellCoords(neighborCellID);
        double nCenterX = (nCoords.first + 0.5) * cellSizeX_ - boxSize_[0] / 2.0;
        double nCenterY = (nCoords.second + 0.5) * cellSizeY_ - boxSize_[1] / 2.0;

        for (int k = 0; k < ocp; ++k) {
            int targetSlot = flatIndex(neighborCellID, k);
            double targetRadius = cellRadius_[targetSlot];
            double tRelX = relPosX_[targetSlot];
            double tRelY = relPosY_[targetSlot];
            double tGlobalX = nCenterX + tRelX;
            double tGlobalY = nCenterY + tRelY;

            double dx = tGlobalX - aGlobalX;
            double dy = tGlobalY - aGlobalY;
            // Minimum image
            dx = apply_pbc(dx, boxSize_[0]);
            dy = apply_pbc(dy, boxSize_[1]);

            callback(neighborCellID, k, dx, dy, targetRadius);
        }
    }
}
