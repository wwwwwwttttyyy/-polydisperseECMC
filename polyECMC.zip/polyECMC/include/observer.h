#pragma once
#include <iostream>
/**
 * @brief Observer for physical measurements and statistics in ECMC
 *
 * Responsibilities:
 *  1. Pressure measurement (X/Y components separately):
 *     βP = ρ * (1 + Σ(deltaIJ) / L_total), where ρ = N/V
 *     deltaIJ: collision transfer, L_total: total chain length
 *  2. Collision statistics
 *  3. Sampling interval management
 *  4. Extensible for RDF, energy, configuration output, etc.
 */
class Observer {
public:
    Observer() 
        : collision_count_(0),
          accumulated_delta_x_(0.0),
          accumulated_delta_y_(0.0),
          accumulated_length_x_(0.0),
          accumulated_length_y_(0.0),
          chain_counter_(0),
          configuration_counter_(0) {}
    
    // ========== Update methods (called by EcmcEngine) ==========
    
    /**
     * @brief Record a collision event
     * @param deltaIJ Collision contribution (sqrt(σ² - dy²) or sqrt(σ² - dx²))
     * @param direction 0 = X, 1 = Y
     */
    void recordCollision(double deltaIJ, int direction) {
        ++collision_count_;
        if (direction == 0) {
            accumulated_delta_x_ += deltaIJ;
        } else {
            accumulated_delta_y_ += deltaIJ;
        }
    }
    
    /**
     * @brief Record chain length
     * @param chainLength Length of the chain
     * @param direction 0 = X, 1 = Y
     */
    void recordChainLength(double chainLength, int direction) {
        if (direction == 0) {
            accumulated_length_x_ += chainLength;
        } else {
            accumulated_length_y_ += chainLength;
        }
        ++chain_counter_;
    }
    
    /**
     * @brief Reset accumulators for the current sampling interval
     */
    void resetSamplingInterval() {
        accumulated_delta_x_ = 0.0;
        accumulated_delta_y_ = 0.0;
        accumulated_length_x_ = 0.0;
        accumulated_length_y_ = 0.0;
        chain_counter_ = 0;
        ++configuration_counter_;
    }
    
    // ========== Query methods ==========
    
    long long getCollisionCount() const { return collision_count_; }
    long long getChainCounter() const { return chain_counter_; }
    int getConfigurationCounter() const { return configuration_counter_; }
    
    double getAccumulatedDeltaX() const { return accumulated_delta_x_; }
    double getAccumulatedDeltaY() const { return accumulated_delta_y_; }
    double getAccumulatedLengthX() const { return accumulated_length_x_; }
    double getAccumulatedLengthY() const { return accumulated_length_y_; }
    
    /**
     * @brief Calculate dimensionless pressure factor (1 + Σ deltaIJ / L_total)
     * @return Dimensionless pressure factor
     */
    double calculatePressureFactor() const {
        double total_length = accumulated_length_x_ + accumulated_length_y_;
        double total_delta = accumulated_delta_x_ + accumulated_delta_y_;
        if (total_length > 0) {
            return 1.0 + total_delta / total_length;
        }
        return 1.0;
    }
    
    double calculatePressureFactorX() const {
        if (accumulated_length_x_ > 0) {
            return 1.0 + accumulated_delta_x_ / accumulated_length_x_;
        }
        return 1.0;
    }
    
    double calculatePressureFactorY() const {
        if (accumulated_length_y_ > 0) {
            return 1.0 + accumulated_delta_y_ / accumulated_length_y_;
        }
        return 1.0;
    }
    
    /**
     * @brief Calculate reduced pressure βP* (normalized by (2r)^2)
     * @param N Number of particles
     * @param volume Box volume
     * @param mean_radius Mean radius
     * @return Reduced pressure
     */
    double calculateReducedPressure(int N, double volume, double mean_radius) const {
        double rho = static_cast<double>(N) / volume;
        double total_length = accumulated_length_x_ + accumulated_length_y_;
        double total_delta = accumulated_delta_x_ + accumulated_delta_y_;
        
        if (total_length <= 0) {
            return rho * 4.0 * mean_radius * mean_radius;  // 理想气体项
        }
        
        double mean_diameter = 2.0 * mean_radius;
        double normalization = mean_diameter * mean_diameter;
        return (rho + rho * (total_delta / total_length)) * normalization;
    }
    
    /**
     * @brief Calculate X component of reduced pressure
     */
    double calculateReducedPressureX(int N, double volume, double mean_radius) const {
        double rho = static_cast<double>(N) / volume;
        double mean_diameter = 2.0 * mean_radius;
        double normalization = mean_diameter * mean_diameter;
        
        if (accumulated_length_x_ <= 0) {
            return rho * normalization;
        }
        return (rho + rho * (accumulated_delta_x_ / accumulated_length_x_)) * normalization;
    }
    
    /**
     * @brief Calculate Y component of reduced pressure
     */
    double calculateReducedPressureY(int N, double volume, double mean_radius) const {
        double rho = static_cast<double>(N) / volume;
        double mean_diameter = 2.0 * mean_radius;
        double normalization = mean_diameter * mean_diameter;
        
        if (accumulated_length_y_ <= 0) {
            return rho * normalization;
        }
        return (rho + rho * (accumulated_delta_y_ / accumulated_length_y_)) * normalization;
    }
    /**
     * @brief Sample and print pressure if enough data is collected
     * @param N Number of particles
     * @param volume Box volume
     * @param mean_radius Mean radius
     * @param sample_interval Sampling interval (number of chains)
     * @return True if sampling was performed
     */
    bool sampleAndReportPressure(int N, double volume, double mean_radius, long long sample_interval) {

        if (chain_counter_ < sample_interval) {
            return false;
        }
        double pressure = calculateReducedPressure(N, volume, mean_radius);
        double pressure_x = calculateReducedPressureX(N, volume, mean_radius);
        double pressure_y = calculateReducedPressureY(N, volume, mean_radius);

        std::cout << "Pressure [" << configuration_counter_ << "]: "
                  << "βP* = " << pressure 
                  << " (Px = " << pressure_x << ", Py = " << pressure_y << ")\n";

        resetSamplingInterval();
        return true;
    }
    
    
private:
    // Global statistics
    long long collision_count_;      ///< Total number of collisions (cumulative)
    // Accumulators for current sampling interval (reset periodically)
    double accumulated_delta_x_;     ///< Accumulated deltaIJ in X
    double accumulated_delta_y_;     ///< Accumulated deltaIJ in Y
    double accumulated_length_x_;    ///< Accumulated chain length in X
    double accumulated_length_y_;    ///< Accumulated chain length in Y
    // Counters
    long long chain_counter_;        ///< Chain count in current sampling interval
    int configuration_counter_;      ///< Output configuration index
};
