#pragma once

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>

/**
 * @brief Pressure observer for ECMC: specialized for pressure measurement
 *
 * Physics:
 *   βP* = [ρ + ρ·(Σδ/L)] × (2r̄)², where ρ = N/V
 *   δ = dx - L_event (X) or dy - L_event (Y), L = n_chains × chain_length
 *   (2r̄)² is the normalization factor, r̄ is mean radius
 *
 * Usage:
 *   1. initialize(...) - set system parameters
 *   2. recordChain(direction) - call at the start of each chain (count only)
 *   3. recordCollision(deltaIJ, direction) - call at each collision
 *   4. sampleAndReport() - call at sampling interval
 */
class PressureObserver {
public:
    PressureObserver() 
        : N_(0),
          volume_(0.0),
          mean_radius_(0.0),
          chain_length_(0.0),
          sample_interval_(0),
          accumulated_delta_x_(0.0),
          accumulated_delta_y_(0.0),
          chain_count_x_(0),
          chain_count_y_(0),
          sample_counter_(0),
          equilibration_samples_(0) {}
    
    /**
     * @brief Initialize system parameters (call once)
     * @param N Number of particles
     * @param volume Box volume/area
     * @param mean_radius Mean radius
     * @param chain_length Length of a single chain
     * @param sample_interval Sampling interval (number of chains)
     */
    void initialize(int N, double volume, double mean_radius, double chain_length, long long sample_interval) {
        N_ = N;
        volume_ = volume;
        mean_radius_ = mean_radius;
        chain_length_ = chain_length;
        sample_interval_ = sample_interval;
    }
    
    /**
     * @brief Record collision contribution
     * @param deltaIJ Contact distance at collision
     * @param direction 0 = X, 1 = Y
     */
    void recordCollision(double deltaIJ, int direction) {
        if (direction == 0) {
            accumulated_delta_x_ += deltaIJ;
        } else {
            accumulated_delta_y_ += deltaIJ;
        }
    }
    
    /**
     * @brief Record the start of a chain (count only)
     * @param direction 0 = X, 1 = Y
     *
     * Should be called at chain start, before collision loop
     */
    void recordChain(int direction) {
        if (direction == 0) {
            ++chain_count_x_;
        } else {
            ++chain_count_y_;
        }
    }
    
    /**
     * @brief Calculate reduced pressure βP*
     */
    double calculateReducedPressure() const {
        double rho = static_cast<double>(N_) / volume_;
        long long total_chain_count = chain_count_x_ + chain_count_y_;
        double total_length = total_chain_count * chain_length_;
        double total_delta = accumulated_delta_x_ + accumulated_delta_y_;
        
        double normalization = 4.0 * mean_radius_ * mean_radius_;  // (2r̄)²
        
        if (total_length <= 0) {
            return rho * normalization;  // Ideal gas term
        }
        
        return (rho + rho * (total_delta / total_length)) * normalization;
    }
    
    /**
     * @brief Calculate reduced pressure in X direction
     */
    double calculateReducedPressureX() const {
        double rho = static_cast<double>(N_) / volume_;
        double normalization = 4.0 * mean_radius_ * mean_radius_;
        double length_x = chain_count_x_ * chain_length_;
        
        if (length_x <= 0) {
            return rho * normalization;
        }
        
        return (rho + rho * (accumulated_delta_x_ / length_x)) * normalization;
    }
    
    /**
     * @brief Calculate reduced pressure in Y direction
     */
    double calculateReducedPressureY() const {
        double rho = static_cast<double>(N_) / volume_;
        double normalization = 4.0 * mean_radius_ * mean_radius_;
        double length_y = chain_count_y_ * chain_length_;
        
        if (length_y <= 0) {
            return rho * normalization;
        }
        
        return (rho + rho * (accumulated_delta_y_ / length_y)) * normalization;
    }
    
    /**
     * @brief Sample and print pressure (call at sampling interval)
     * @return True if sampling performed
     *
     * Note: This outputs the cumulative average and does not reset accumulators.
     * For smaller statistical error, increase sampling interval or use clear() after equilibration.
     */
    bool sampleAndReport() {
        long long total_chains = chain_count_x_ + chain_count_y_;
        if (total_chains < sample_interval_) {
            return false;
        }
        
        // Calculate cumulative average pressure (from all data since clear() or initialization)
        double pressure = calculateReducedPressure();
        double pressure_x = calculateReducedPressureX();
        double pressure_y = calculateReducedPressureY();
        
        // Record to historical data
        pressure_history_.push_back(pressure);
        pressure_x_history_.push_back(pressure_x);
        pressure_y_history_.push_back(pressure_y);
        chain_count_history_.push_back(total_chains);
        
        std::cout << "Pressure [" << sample_counter_ << "]: "
                  << "betaP* = " << pressure 
                  << " (Px = " << pressure_x << ", Py = " << pressure_y << ")"
                  << " [total " << total_chains << " chains]\n";
        
        ++sample_counter_;
        // Note: Does not call reset(), continuously accumulates to reduce variance
        return true;
    }
    
    /**
     * @brief Clear all accumulators (for removing equilibration phase)
     *
     * Call after equilibration, before production sampling.
     */
    void clear() {
        accumulated_delta_x_ = 0.0;
        accumulated_delta_y_ = 0.0;
        chain_count_x_ = 0;
        chain_count_y_ = 0;
        sample_counter_ = 0;
        
        // Mark the end of the relaxation phase
        equilibration_samples_ = pressure_history_.size();
    }
    
    /**
     * @brief Reset current sampling interval
     */
    void reset() {
        accumulated_delta_x_ = 0.0;
        accumulated_delta_y_ = 0.0;
        chain_count_x_ = 0;
        chain_count_y_ = 0;
        ++sample_counter_;
    }
    
    // Query interface
    long long getTotalChainCount() const { return chain_count_x_ + chain_count_y_; }
    int getSampleCounter() const { return sample_counter_; }
    
    /**
     * @brief Write pressure statistics to file
     * @param filename Output file name
     */
    void writePressureData(const std::string& filename) const {
        std::ofstream ofs(filename);
        if (!ofs) {
            std::cerr << "Error: Cannot open " << filename << " for writing\n";
            return;
        }
        
        // Calculate statistics for post-equilibration data
        size_t n_prod = pressure_history_.size() - equilibration_samples_;
        double mean = 0.0, mean_x = 0.0, mean_y = 0.0;
        
        if (n_prod > 0) {
            for (size_t i = equilibration_samples_; i < pressure_history_.size(); ++i) {
                mean += pressure_history_[i];
                mean_x += pressure_x_history_[i];
                mean_y += pressure_y_history_[i];
            }
            mean /= n_prod;
            mean_x /= n_prod;
            mean_y /= n_prod;
        }
        
        // Calculate variance (post-equilibration only)
        double var = 0.0, var_x = 0.0, var_y = 0.0;
        if (n_prod > 1) {
            for (size_t i = equilibration_samples_; i < pressure_history_.size(); ++i) {
                double diff = pressure_history_[i] - mean;
                double diff_x = pressure_x_history_[i] - mean_x;
                double diff_y = pressure_y_history_[i] - mean_y;
                var += diff * diff;
                var_x += diff_x * diff_x;
                var_y += diff_y * diff_y;
            }
            var /= (n_prod - 1);
            var_x /= (n_prod - 1);
            var_y /= (n_prod - 1);
        }
        
        // Write statistical summary
        ofs << "# ECMC Pressure Data\n";
        ofs << "# Equilibration samples: " << equilibration_samples_ << "\n";
        ofs << "# Production samples: " << n_prod << "\n";
        ofs << "#\n";
        ofs << "# Production Statistics (after equilibration):\n";
        ofs << "#   betaP* = " << mean << " +/- " << std::sqrt(var) << "\n";
        ofs << "#   Px     = " << mean_x << " +/- " << std::sqrt(var_x) << "\n";
        ofs << "#   Py     = " << mean_y << " +/- " << std::sqrt(var_y) << "\n";
        ofs << "#\n";
        ofs << "# Columns: Sample  Chains  betaP*  Px  Py  Phase\n";
        ofs << "#\n";
        
        // Write all sampled data
        for (size_t i = 0; i < pressure_history_.size(); ++i) {
            ofs << i << "  "
                << chain_count_history_[i] << "  "
                << pressure_history_[i] << "  "
                << pressure_x_history_[i] << "  "
                << pressure_y_history_[i] << "  "
                << (i < equilibration_samples_ ? "equilibration" : "production")
                << "\n";
        }
        
        std::cout << "Pressure data saved to " << filename << "\n";
        std::cout << "  Production: betaP* = " << mean << " +/- " << std::sqrt(var) << "\n";
    }

private:
    // System parameters (set at initialization, fixed during run)
    int N_;                          ///< Number of particles
    double volume_;                  ///< Box volume
    double mean_radius_;             ///< Mean radius
    double chain_length_;            ///< Chain length
    long long sample_interval_;      ///< Sampling interval
    // Accumulators (reset each sampling interval)
    double accumulated_delta_x_;     ///< Accumulated δ in X
    double accumulated_delta_y_;     ///< Accumulated δ in Y
    long long chain_count_x_;        ///< Chain count in X
    long long chain_count_y_;        ///< Chain count in Y
    int sample_counter_;             ///< Number of samples (output index)
    // History (for statistics and output)
    std::vector<double> pressure_history_;       ///< Pressure history
    std::vector<double> pressure_x_history_;     ///< X direction pressure history
    std::vector<double> pressure_y_history_;     ///< Y direction pressure history
    std::vector<long long> chain_count_history_; ///< Chain count history
    size_t equilibration_samples_;               ///< Number of equilibration samples
};
