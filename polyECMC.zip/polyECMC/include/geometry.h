#pragma once
#include <cmath>
#include <limits>



inline double apply_pbc(double x, double L)
{
    return x - L * std::floor(x / L + 0.5);
}   
class IGeometry {
public:
    virtual ~IGeometry() = default;
    
        /**
        * @brief Compute event distance for ECMC (Event-Chain Monte Carlo)
        * @param dx Relative x position of target to active (x2 - x1)
        * @param dy Relative y position of target to active (y2 - y1)
        * @param r1 Radius of active particle
        * @param r2 Radius of target particle
        * @return Event distance L: distance the active particle must move to collide
        *
        * Physics: Find L ≥ 0 such that |(L, 0) - (dx, dy)| = r1 + r2 (for X move), or |(0, L) - (dx, dy)| = r1 + r2 (for Y move).
        * Returns:
        *   - L > 0: collision will occur after moving L
        *   - inf: no collision (particles do not meet)
        *   - L < 0: overlap (treated as immediate collision)
        */
    virtual double XeventDistance(
        double dx, double dy,
        double r1, double r2) const = 0;
    
    virtual double YeventDistance(
        double dx, double dy,
        double r1, double r2) const = 0;
};


/**
 * @brief Hard-disk collision geometry for ECMC
 *
 * Implements event distance for hard disks in 2D.
 */
class HardDiskGeometry : public IGeometry {
public:
    inline double XeventDistance(
        double dx, double dy,
        double r1, double r2) const override
    {
        double sigma = r1 + r2;
        double sigma_sq = sigma * sigma;
        double dy_sq = dy * dy;
        
        if (dy_sq >= sigma_sq) {
            return INF;
        }
        
        double lcoll = dx - std::sqrt(sigma_sq - dy_sq);
        return lcoll;
    }
    
    inline double YeventDistance(
        double dx, double dy,
        double r1, double r2) const override
    {
        double sigma = r1 + r2;
        double sigma_sq = sigma * sigma;
        double dx_sq = dx * dx;

        if (dx_sq >= sigma_sq) {
            return INF;
        }
        
        double lcoll = dy - std::sqrt(sigma_sq - dx_sq);
        return lcoll;
    }

    
private:
    static constexpr double INF = std::numeric_limits<double>::infinity();
    static constexpr double EPSILON = 1e-12;
};

