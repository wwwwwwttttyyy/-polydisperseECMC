#pragma once
#include <vector>
#include <array>
#include <cmath>
#include <algorithm>
#include <limits>
#include <string>

/**
 * @brief System class representing a collection of particles in 2D space
 * 
 * This class manages particle positions, radii, and system properties for
 * Event-Chain Monte Carlo (ECMC) simulations. It provides methods for
 * particle manipulation, periodic boundary conditions, and configuration I/O.
 */
class System {
public:
    // ========== Construction and Initialization ==========
    System() = default;
    explicit System(size_t n, const std::array<double, 2>& box_);  ///< Preallocate n particles and set box boundaries
    
    std::vector<double> x;        ///< x coordinates [N]
    std::vector<double> y;        ///< y coordinates [N]
    std::vector<double> radius;   ///< Particle radii [N] (key for polydispersity)
    std::vector<int> typeID;      ///< Type identifiers [N] (optional, for statistics)
    std::array<double, 2> boxsize;    ///< {Lx, Ly} box dimensions, assumed centered at origin
    
    // Radius statistics for cell list construction
    double radiusMax = 0.0;       ///< Maximum particle radius
    double radiusMean = 0.0;      ///< Mean particle radius
    double radiusMin = std::numeric_limits<double>::infinity();  ///< Minimum particle radius

    size_t size() const { return x.size(); }
    
    /// Preallocate memory for n particles
    void reserve(size_t n);

    /// Clear all data and release memory
    void clear();
    
    // ========== Particle Operations ==========
    void addParticle(double x_, double y_, double r_, int tid = 0);
    void removeParticle(size_t index);
    void updateMaxMeanRadius();
    
    // ========== File I/O ==========
    /**
     * @brief Save system configuration to text file (human readable)
     * @param filename Output filename
     * 
     * Format:
     *   Line 1: Lx Ly
     *   Subsequent lines: x y radius
     */
    void saveConfig(const std::string& filename) const;
    
    /**
     * @brief Load system configuration from text file
     * @param filename Input filename
     * 
     * Format same as saveConfig
     * Clears current system and loads new data
     * Automatically centers the system from [0,Lx]×[0,Ly] to symmetric coordinates
     * If particles are exactly on boundaries, adjusts box size by 1e-6 to avoid floating-point precision issues
     */
    void loadConfig(const std::string& filename);
    
    /**
     * @brief Save system configuration to binary file (efficient)
     * @param filename Output filename
     * 
     * Format (all data as double):
     *   - Lx, Ly (box dimensions)
     *   - N (number of particles, stored as double)
     *   - x[0], y[0], r[0]
     *   - x[1], y[1], r[1]
     *   - ...
     */
    void saveConfigBinary(const std::string& filename) const;
    
    /**
     * @brief Load system configuration from binary file
     * @param filename Input filename
     * 
     * Automatically centers the system from [0,Lx]×[0,Ly] to symmetric coordinates
     * If particles are exactly on boundaries, adjusts box size by 1e-6 to avoid floating-point precision issues
     */
    void loadConfigBinary(const std::string& filename);
    
    // ========== Box Operations and PBC ==========
    /// Check for particle overlaps in initial configuration
    bool checkOverlap(double overlapThreshold) const;
    
    /// Apply periodic boundary conditions to particle i
    void applyPBC(size_t i);
    
    /// Compute displacement vector between particles i and j with PBC
    std::array<double, 2> displacement(size_t i, size_t j) const;
    
    /// Compute distance between particles i and j with PBC
    double distance(size_t i, size_t j) const;
    
    // ========== Statistical Calculations ==========
    /**
     * @brief Calculate packing fraction of the system
     * @return φ = Σ(πr²) / (Lx * Ly)
     */
    double getPackingFraction() const;
};
