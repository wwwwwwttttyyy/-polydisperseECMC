#pragma once
#include "cell.h"
#include "geometry.h"
#include <limits>

/**
 * @brief Collision event for ECMC (Event-Chain Monte Carlo)
 *
 * Represents the first collision encountered by an active particle moving in a given direction.
 */
struct CollisionEvent {
    double distance;       ///< Distance to collision (INF if no collision)
    int targetCellID;      ///< Cell ID of the collision partner
    int targetSlotK;       ///< Slot index of the collision partner
    // Relative position at the start of the event
    double dxInitial;      ///< Initial x separation
    double dyInitial;      ///< Initial y separation
    // Pressure contribution at collision
    double deltaIJ;        ///< Contact distance: X: sqrt(σ² - dy²), Y: sqrt(σ² - dx²)
    
    /**
     * @brief Whether a valid collision was found
     * @return true if collision found within maxDistance
     */
    bool hasCollision() const {
        return distance < std::numeric_limits<double>::infinity();
    }
    
    /**
     * @brief Relative x separation at collision (for pressure, only valid for X moves)
     */
    double getDxAtCollision() const {
        return dxInitial - distance;
    }
    
    /**
     * @brief Relative y separation at collision (for pressure, only valid for Y moves)
     */
    double getDyAtCollision() const {
        return dyInitial - distance;
    }
    
    /**
     * @brief Default: no collision (distance = INF)
     */
    CollisionEvent()
        : distance(std::numeric_limits<double>::infinity()),
          targetCellID(-1),
          targetSlotK(-1),
          dxInitial(0.0),
          dyInitial(0.0),
          deltaIJ(0.0) {}
};

/**
 * @brief Find the first collision for an active particle moving in +X direction.
 *
 * Only the 6 forward neighbor cells are searched (directions {2, 5, 8, 1, 4, 7}).
 * Self-collision is avoided by an epsilon check in direction 4.
 *
 * @param grid Cell grid structure
 * @param activeCellID Cell ID of the active particle
 * @param activeSlotK Slot index of the active particle
 * @param geom Geometry model for event distance
 * @param maxDistance Maximum search distance
 * @return Nearest collision event (distance = INF if none)
 */
CollisionEvent findCollisionX(
    const CellGrid& grid,
    int activeCellID,
    int activeSlotK,
    const IGeometry& geom,
    double maxDistance);

/**
 * @brief Find the first collision for an active particle moving in +Y direction.
 *
 * Only the 6 forward neighbor cells are searched (directions {6, 7, 8, 3, 4, 5}).
 *
 * @param grid Cell grid structure
 * @param activeCellID Cell ID of the active particle
 * @param activeSlotK Slot index of the active particle
 * @param geom Geometry model for event distance
 * @param maxDistance Maximum search distance
 * @return Nearest collision event (distance = INF if none)
 */
CollisionEvent findCollisionY(
    const CellGrid& grid,
    int activeCellID,
    int activeSlotK,
    const IGeometry& geom,
    double maxDistance);
